GDmotion - Phase 2 (first editor features)
==========================================

You need: a phone, a free GitHub account, and Geode installed on your Android
Geometry Dash. You do NOT need a computer.

IMPORTANT: GitHub does not unpack zip files you upload. This is why the build
workflow unpacks gdmotion-source.zip by itself every time it runs.
Because of that, the repository only ever holds the zip + the workflow file.
To change anything (even one line), upload a NEW gdmotion-source.zip with the
same name - it replaces the old one.

Steps
-----
1. Create the repository
   - Open github.com in your phone browser and log in.
   - Tap "+" (top right) > "New repository". Name it gdmotion, pick Public or
     Private, tap "Create repository".

2. Upload the zip (do NOT unpack it)
   - In the new repository tap "Add file" > "Upload files".
   - Choose gdmotion-source.zip, wait for it to finish, then tap
     "Commit changes" (keep "Commit directly to the main branch").
   - If you cannot see "Add file", open your browser menu and turn on
     "Desktop site", then reload the page.

3. Create the workflow file
   - Tap "Add file" > "Create new file".
   - In the name box type exactly:   .github/workflows/build.yml
     (typing the slashes makes the folders for you).
   - Paste the full text of build.yml (the separate file I gave you).
   - Tap "Commit changes" > "Commit directly to the main branch".

4. Run it
   - Committing the workflow starts a build by itself. To start one by hand:
     tap "Actions" > "Build GDmotion" > "Run workflow" > "Run workflow".
   - A build takes several minutes. Three jobs run (Windows, Android32,
     Android64) and then one job called "Package .geode" combines them.

5. Download the result
   - Tap the finished run (green tick). Scroll to the bottom to "Artifacts".
   - Tap "GDmotion-geode". GitHub gives you a .zip - open it with your file
     manager and extract it. Inside is a file ending in .geode.

6. Install on Android
   - Copy the .geode file into this folder:
       /storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/
   - Start Geometry Dash. GDmotion should appear in the Geode mod list.
   - Open a level in the EDITOR. On the right side you should see a small
     "Anim" button. Press it: a dark timeline bar appears near the bottom and a
     "Key" button shows under "Anim".
       |< < > >|   move the playhead by 10 / 1 frame
       Z+  Z-      zoom the timeline
       <<  >>      scroll the timeline
       G-  G+      choose the group number the keys belong to
       Key         select an object, then press: stores its X and Y at the playhead
       Del         removes the keys of the chosen group at the playhead
   - The animation is only kept in memory (no saving yet) and no triggers are
     created yet. Selecting one object does NOT select its whole group yet.
   - The buttons may sit on top of editor buttons. If so, send me a screenshot;
     only three numbers at the top of src/editor/EditorHook.cpp need to change.
   - The startup check is still in the Geode log:
     "GDmotion core self-check passed".

If the build fails
------------------
Open the failed run, open the red step, copy the log (or at least everything
from the FIRST line that says "error") and send it to me. I will name the
first real error, send only the changed files in full, and tell you whether
the fix can affect the other platform.

Phase 2 only changes gdmotion-source.zip. The workflow file (build.yml) stays the
same, so just upload the new zip with the same name.

Where the versions live
-----------------------
The Geode version ("geode") and the Geometry Dash version ("gd") are written
only in mod.json. The workflow reads the Geode version from there. The mod
version must also match "project(GDmotion VERSION ...)" in CMakeLists.txt.
