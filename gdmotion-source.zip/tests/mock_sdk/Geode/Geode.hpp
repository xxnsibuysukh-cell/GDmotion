// MOCK of the Geode SDK - see tests/mock_sdk/README.txt
#pragma once

#include <cstddef>
#include <cstdio>
#include <new>
#include <string>
#include <vector>

namespace cocos2d {

struct CCPoint {
    float x;
    float y;
    CCPoint() : x(0.f), y(0.f) {}
    CCPoint(float a, float b) : x(a), y(b) {}
};
struct CCSize {
    float width;
    float height;
    CCSize() : width(0.f), height(0.f) {}
    CCSize(float w, float h) : width(w), height(h) {}
};
struct ccColor4B {
    unsigned char r, g, b, a;
};
inline ccColor4B ccc4(int r, int g, int b, int a) {
    ccColor4B c;
    c.r = static_cast<unsigned char>(r);
    c.g = static_cast<unsigned char>(g);
    c.b = static_cast<unsigned char>(b);
    c.a = static_cast<unsigned char>(a);
    return c;
}

class CCObject {
public:
    virtual ~CCObject() {}
    void autorelease() {}
};
typedef void (CCObject::*SEL_MenuHandler)(CCObject*);

class CCNode : public CCObject {
public:
    std::vector<CCNode*> children;
    CCNode* parent = nullptr;
    std::string id;
    int tag = 0;
    bool visible = true;
    CCPoint pos;
    CCSize size;

    virtual bool init() { return true; }
    static CCNode* create() {
        CCNode* n = new CCNode();
        n->init();
        return n;
    }
    void addChild(CCNode* c) {
        children.push_back(c);
        c->parent = this;
    }
    void addChild(CCNode* c, int) { addChild(c); }
    void removeAllChildrenWithCleanup(bool) { children.clear(); }
    CCNode* getChildByID(const std::string& s) {
        for (size_t i = 0; i < children.size(); ++i) {
            if (children[i]->id == s) return children[i];
        }
        return nullptr;
    }
    void setID(const std::string& s) { id = s; }
    void setTag(int t) { tag = t; }
    int getTag() const { return tag; }
    void setVisible(bool v) { visible = v; }
    bool isVisible() const { return visible; }
    void setPosition(const CCPoint& p) { pos = p; }
    float getPositionX() const { return pos.x; }
    float getPositionY() const { return pos.y; }
    void setContentSize(const CCSize& s) { size = s; }
    void setScale(float) {}
    void setAnchorPoint(const CCPoint&) {}
    void ignoreAnchorPointForPosition(bool) {}
};

class CCLayerColor : public CCNode {
public:
    static CCLayerColor* create(const ccColor4B&, float w, float h) {
        CCLayerColor* n = new CCLayerColor();
        n->size = CCSize(w, h);
        return n;
    }
};
class CCLabelBMFont : public CCNode {
public:
    std::string text;
    static CCLabelBMFont* create(const char* t, const char*) {
        CCLabelBMFont* n = new CCLabelBMFont();
        n->text = t;
        return n;
    }
};
class CCMenu : public CCNode {
public:
    static CCMenu* create() { return new CCMenu(); }
};
class CCMenuItem : public CCNode {
public:
    bool enabled = true;
    void setEnabled(bool e) { enabled = e; }
    bool isEnabled() const { return enabled; }
};
class CCArray : public CCObject {
public:
    std::vector<CCObject*> items;
    unsigned int count() const { return static_cast<unsigned int>(items.size()); }
    CCObject* objectAtIndex(unsigned int i) { return items[i]; }
};
class CCDirector {
public:
    static CCDirector* sharedDirector() {
        static CCDirector d;
        return &d;
    }
    CCSize getWinSize() { return CCSize(569.f, 320.f); }
};

}  // namespace cocos2d

#define menu_selector(_SELECTOR) (cocos2d::SEL_MenuHandler)(&_SELECTOR)
#define CC_SAFE_DELETE(p) \
    do {                  \
        delete (p);       \
        (p) = nullptr;    \
    } while (0)

class CCMenuItemSpriteExtra : public cocos2d::CCMenuItem {
public:
    cocos2d::CCObject* target = nullptr;
    cocos2d::SEL_MenuHandler callback = nullptr;
    static CCMenuItemSpriteExtra* create(cocos2d::CCNode* sprite, cocos2d::CCObject* t,
                                         cocos2d::SEL_MenuHandler cb) {
        CCMenuItemSpriteExtra* n = new CCMenuItemSpriteExtra();
        n->addChild(sprite);
        n->target = t;
        n->callback = cb;
        return n;
    }
    void activate() {
        if (enabled && target && callback) (target->*callback)(this);
    }
};
class GameObject : public cocos2d::CCNode {};
class LevelEditorLayer : public cocos2d::CCNode {};
class EditorUI : public cocos2d::CCNode {
public:
    GameObject* m_selectedObject = nullptr;
    cocos2d::CCArray* m_selectedObjects = nullptr;
    virtual bool init(LevelEditorLayer*) { return true; }
};

namespace geode {
namespace log {
template <class... A> void info(const char* f, A&&...) { std::printf("[info] %s\n", f); }
template <class... A> void warn(const char* f, A&&...) { std::printf("[warn] %s\n", f); }
template <class... A> void error(const char* f, A&&...) { std::printf("[error] %s\n", f); }
}  // namespace log
namespace prelude {
using namespace ::cocos2d;
namespace log = ::geode::log;
inline std::string operator""_spr(const char* s, size_t) { return std::string("gdmotion.gdmotion/") + s; }
}  // namespace prelude
}  // namespace geode

#define $execute static void gdm_mock_fn(); static int gdm_mock_reg = (gdm_mock_fn(), 0); static void gdm_mock_fn()
#define $modify(Name, Base) Name : public Base
