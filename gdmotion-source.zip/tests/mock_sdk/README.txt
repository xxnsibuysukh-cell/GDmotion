NOT the real Geode SDK.

A tiny stand-in written from my own assumptions about the cocos2d/Geode API.
It only lets the editor files (src/editor) be syntax-checked and exercised on a
normal computer. Passing against this mock does NOT prove the code compiles
against the real SDK. It is never part of the mod build (CMake only reads src/).
