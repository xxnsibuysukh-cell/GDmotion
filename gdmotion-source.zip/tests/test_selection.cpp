// Tests for the timeline "follow" math and the group selection logic.
#include <cmath>
#include <vector>

#include "SelectionGroups.hpp"
#include "Timeline.hpp"
#include "check.hpp"

using namespace gdm;

static std::vector<int32_t> groupsOf(int a, int b = 0, int c = 0) {
    std::vector<int32_t> g;
    if (a != 0) g.push_back(a);
    if (b != 0) g.push_back(b);
    if (c != 0) g.push_back(c);
    return g;
}

void testFollowFrame() {
    TimelineView v;
    v.scrollFrame = 0.0;
    v.pixelsPerFrame = 10.0;
    v.widthPx = 500.0;  // 50 frames visible
    const int32_t length = 1000;

    followFrame(v, 20.0, length);  // already in view: no move
    CHECK(approx(v.scrollFrame, 0.0, 1e-12));

    followFrame(v, 200.0, length);  // far to the right
    CHECK(frameToX(v, 200.0) >= 0.0 && frameToX(v, 200.0) <= v.widthPx);

    followFrame(v, 10.0, length);  // far to the left
    CHECK(frameToX(v, 10.0) >= 0.0 && frameToX(v, 10.0) <= v.widthPx);

    followFrame(v, 5000.0, length);  // beyond the end: view stays valid
    CHECK(v.scrollFrame <= 1000.0 - 50.0 + 1e-9);
    CHECK(v.scrollFrame >= 0.0);

    const double before = v.scrollFrame;
    followFrame(v, std::nan(""), length);  // ignored
    CHECK(approx(v.scrollFrame, before, 1e-12));

    TimelineView s;
    s.pixelsPerFrame = 10.0;
    s.widthPx = 500.0;
    followFrame(s, 19.0, 20);  // short project: no scrolling possible
    CHECK(approx(s.scrollFrame, 0.0, 1e-12));
}

void testSelectionGroups() {
    std::vector<std::vector<int32_t> > objects;
    objects.push_back(groupsOf(1));        // 0
    objects.push_back(groupsOf(1, 2));     // 1
    objects.push_back(groupsOf(2));        // 2
    objects.push_back(groupsOf(3));        // 3
    objects.push_back(groupsOf(0));        // 4  (no group)
    objects.push_back(std::vector<int32_t>(2, -1));  // 5  (ids <= 0 are ignored)

    std::vector<size_t> sel;
    sel.push_back(0);
    std::vector<size_t> r = expandSelectionByGroups(objects, sel);
    CHECK(r.size() == 2 && r[0] == 0 && r[1] == 1);  // not 2: no chaining

    sel.assign(1, 1);
    r = expandSelectionByGroups(objects, sel);
    CHECK(r.size() == 3 && r[0] == 0 && r[1] == 1 && r[2] == 2);

    sel.assign(1, 4);
    r = expandSelectionByGroups(objects, sel);
    CHECK(r.size() == 1 && r[0] == 4);

    sel.assign(1, 5);
    r = expandSelectionByGroups(objects, sel);
    CHECK(r.size() == 1 && r[0] == 5);

    sel.clear();
    CHECK(expandSelectionByGroups(objects, sel).empty());

    sel.assign(1, 99);  // out of range
    CHECK(expandSelectionByGroups(objects, sel).empty());

    sel.clear();
    sel.push_back(0);
    sel.push_back(0);
    sel.push_back(3);  // duplicates and several picks
    r = expandSelectionByGroups(objects, sel);
    CHECK(r.size() == 3 && r[0] == 0 && r[1] == 1 && r[2] == 3);

    CHECK(expandSelectionByGroups(std::vector<std::vector<int32_t> >(), sel).empty());
}
