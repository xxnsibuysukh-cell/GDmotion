// Tiny shared helpers for the plain C++ tests.
#pragma once

#include <cmath>
#include <cstdio>

inline int g_checks = 0;
inline int g_failed = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        ++g_checks;                                                          \
        if (!(cond)) {                                                       \
            ++g_failed;                                                      \
            std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);      \
        }                                                                    \
    } while (0)

inline bool approx(double a, double b, double eps) { return std::fabs(a - b) <= eps; }
