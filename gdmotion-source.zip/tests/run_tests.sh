#!/bin/sh
# Run from the project root:  sh tests/run_tests.sh
# Needs g++ (C++20). No Geode SDK needed: the editor test uses tests/mock_sdk.
set -e
echo "== core tests =="
g++ -std=c++20 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Isrc/core -Itests \
    src/core/*.cpp tests/test_core.cpp tests/test_easing.cpp tests/test_selection.cpp -o /tmp/gdm_core_tests
/tmp/gdm_core_tests
echo "== timeline bar against the MOCK sdk =="
g++ -std=c++20 -Wall -Wextra -Wshadow -Isrc -Itests/mock_sdk -Itests \
    src/core/*.cpp src/editor/TimelineBar.cpp tests/test_bar_mock.cpp -o /tmp/gdm_bar_tests
/tmp/gdm_bar_tests
