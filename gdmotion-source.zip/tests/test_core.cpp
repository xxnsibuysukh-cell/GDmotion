// Plain C++ tests for the pure core (no Geode SDK needed).
// Build and run:
// Run everything with:  sh tests/run_tests.sh   (from the project root)

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "Bake.hpp"
#include "check.hpp"
#include "Easing.hpp"
#include "Project.hpp"
#include "SelfCheck.hpp"
#include "Serialize.hpp"
#include "Timeline.hpp"

using namespace gdm;

// Defined in tests/test_easing.cpp
void testEasingBasics();
void testEasingShape();
// Defined in tests/test_selection.cpp
void testFollowFrame();
void testSelectionGroups();

static Track makeTrack(int id, int group, Property prop) {
    Track t;
    t.id = id;
    t.group = group;
    t.prop = prop;
    return t;
}

static Keyframe key(int frame, double value, EasingType e = EasingType::Linear) {
    Keyframe k;
    k.frame = frame;
    k.value = value;
    k.easing = e;
    return k;
}

static void testKeysAndEvaluate() {
    Track t = makeTrack(1, 5, Property::PosX);
    CHECK(approx(evaluateTrack(t, 10.0), 0.0, 1e-12));  // empty track
    CHECK(addKey(t, key(30, 100.0)));
    CHECK(approx(evaluateTrack(t, 0.0), 100.0, 1e-12));  // single key holds
    CHECK(addKey(t, key(0, 0.0)));
    CHECK(addKey(t, key(60, 0.0)));
    CHECK(t.keys.size() == 3);
    CHECK(t.keys[0].frame == 0 && t.keys[1].frame == 30 && t.keys[2].frame == 60);
    CHECK(!addKey(t, key(30, 80.0)));  // replace
    CHECK(t.keys.size() == 3 && approx(t.keys[1].value, 80.0, 1e-12));
    CHECK(approx(evaluateTrack(t, -10.0), 0.0, 1e-12));
    CHECK(approx(evaluateTrack(t, 15.0), 40.0, 1e-9));
    CHECK(approx(evaluateTrack(t, 30.0), 80.0, 1e-9));
    CHECK(approx(evaluateTrack(t, 45.0), 40.0, 1e-9));
    CHECK(approx(evaluateTrack(t, 500.0), 0.0, 1e-12));
    CHECK(approx(evaluateTrack(t, std::nan("")), 0.0, 1e-12));
    CHECK(!removeKey(t, 31));
    CHECK(removeKey(t, 30));
    CHECK(t.keys.size() == 2);

    Track e = makeTrack(2, 5, Property::Alpha);
    addKey(e, key(0, 0.0, EasingType::EaseIn));
    addKey(e, key(10, 100.0));
    CHECK(approx(evaluateTrack(e, 5.0), 25.0, 1e-9));  // ease-in at t=0.5 is 0.25
}

static Project goodProject() {
    Project p;
    p.name = "demo";
    p.fps = 30;
    p.lengthFrames = 120;
    Track t = makeTrack(1, 10, Property::PosX);
    addKey(t, key(0, 0.0, EasingType::EaseOut));
    addKey(t, key(30, 100.0));
    addKey(t, key(60, 100.0));
    addKey(t, key(90, -25.5, EasingType::BackOut));
    p.tracks.push_back(t);
    Track r = makeTrack(2, 11, Property::Rotation);
    addKey(r, key(0, 0.0));
    addKey(r, key(120, 360.0, EasingType::SineInOut));
    p.tracks.push_back(r);
    return p;
}

static void testValidate() {
    CHECK(validateProject(goodProject()).empty());
    Project p = goodProject();
    p.fps = 0;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.fps = 241;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.lengthFrames = 0;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[1].id = p.tracks[0].id;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].group = 0;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].group = 10000;
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].keys[1].frame = 0;  // not ascending
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].keys[3].frame = 121;  // beyond length
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].keys[0].value = std::nan("");
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.tracks[0].keys[0].easing = static_cast<EasingType>(99);
    CHECK(!validateProject(p).empty());
    p = goodProject();
    p.name = std::string(500, 'x');
    CHECK(!validateProject(p).empty());
}

static void testBake() {
    Track t = makeTrack(7, 3, Property::PosY);
    addKey(t, key(0, 0.0));
    addKey(t, key(30, 100.0));
    std::vector<BakedSegment> s = bakeTrack(t, 30);
    CHECK(s.size() == 1);
    if (s.size() == 1) {
        CHECK(approx(s[0].startSec, 0.0, 1e-12));
        CHECK(approx(s[0].durationSec, 1.0, 1e-12));
        CHECK(approx(s[0].from, 0.0, 1e-12) && approx(s[0].to, 100.0, 1e-12));
        CHECK(s[0].trackId == 7 && s[0].group == 3 && s[0].prop == Property::PosY);
    }
    CHECK(bakeTrack(t, 0).empty());
    CHECK(approx(framesToSeconds(45.0, 30), 1.5, 1e-12));
    CHECK(approx(framesToSeconds(45.0, 0), 0.0, 1e-12));

    Track one = makeTrack(1, 1, Property::Alpha);
    addKey(one, key(5, 50.0));
    CHECK(bakeTrack(one, 30).empty());

    // Hold (equal values) produces no segment.
    Track hold = makeTrack(1, 1, Property::PosX);
    addKey(hold, key(0, 10.0));
    addKey(hold, key(30, 10.0));
    addKey(hold, key(60, 40.0));
    std::vector<BakedSegment> h = bakeTrack(hold, 30);
    CHECK(h.size() == 1);
    if (h.size() == 1) CHECK(approx(h[0].startSec, 1.0, 1e-12));

    // Order across tracks: by start time, then track id.
    Project p;
    p.fps = 10;
    p.lengthFrames = 100;
    Track a = makeTrack(2, 1, Property::PosX);
    addKey(a, key(0, 0.0));
    addKey(a, key(10, 1.0));
    Track b = makeTrack(1, 2, Property::PosX);
    addKey(b, key(0, 0.0));
    addKey(b, key(10, 1.0));
    Track c = makeTrack(3, 3, Property::PosX);
    addKey(c, key(5, 0.0));
    addKey(c, key(15, 1.0));
    p.tracks.push_back(a);
    p.tracks.push_back(b);
    p.tracks.push_back(c);
    std::vector<BakedSegment> all = bakeProject(p);
    CHECK(all.size() == 3);
    if (all.size() == 3) {
        CHECK(all[0].trackId == 1 && all[1].trackId == 2 && all[2].trackId == 3);
    }
}

// Baked segments must reproduce the animation of the original track.
static void testBakeMatchesEvaluate() {
    const Project p = goodProject();
    for (size_t ti = 0; ti < p.tracks.size(); ++ti) {
        const Track& track = p.tracks[ti];
        const std::vector<BakedSegment> segs = bakeTrack(track, p.fps);
        for (int frame = 0; frame <= p.lengthFrames; ++frame) {
            const double expected = evaluateTrack(track, frame);
            const double actual = sampleSegments(segs, framesToSeconds(frame, p.fps), track.keys.front().value);
            CHECK(approx(expected, actual, 1e-9));
        }
    }
    // Fractional frames too.
    const Track& track = p.tracks[0];
    const std::vector<BakedSegment> segs = bakeTrack(track, p.fps);
    for (int i = 0; i < 400; ++i) {
        const double frame = i * 0.3;
        CHECK(approx(evaluateTrack(track, frame),
                   sampleSegments(segs, framesToSeconds(frame, p.fps), 0.0), 1e-9));
    }
}

static void testSerialize() {
    const Project p = goodProject();
    const std::string text = serializeProject(p);
    const ParseResult r = parseProject(text);
    CHECK(r.ok);
    CHECK(serializeProject(r.project) == text);
    CHECK(r.project.tracks.size() == 2);
    if (r.ok && r.project.tracks.size() == 2) {
        CHECK(r.project.name == "demo");
        CHECK(r.project.tracks[0].keys.size() == 4);
        CHECK(r.project.tracks[0].keys[3].value == -25.5);
        CHECK(r.project.tracks[0].keys[3].easing == EasingType::BackOut);
    }

    // Awkward doubles survive exactly.
    Project q = goodProject();
    q.tracks[0].keys[1].value = 0.1 + 0.2;
    q.tracks[0].keys[2].value = 1.0 / 3.0;
    const ParseResult rq = parseProject(serializeProject(q));
    CHECK(rq.ok);
    if (rq.ok) {
        CHECK(rq.project.tracks[0].keys[1].value == q.tracks[0].keys[1].value);
        CHECK(rq.project.tracks[0].keys[2].value == q.tracks[0].keys[2].value);
    }

    // Windows line endings, comments and blank lines are fine.
    std::string crlf;
    for (size_t i = 0; i < text.size(); ++i) {
        if (text[i] == '\n') crlf += "\r\n"; else crlf += text[i];
    }
    CHECK(parseProject("# hello\r\n\r\n" + crlf).ok);

    // Names are cleaned so they stay on one line.
    Project n = goodProject();
    n.name = "line1\nline2";
    const ParseResult rn = parseProject(serializeProject(n));
    CHECK(rn.ok && rn.project.name == "line1 line2");

    // Things that must be rejected.
    CHECK(!parseProject("").ok);
    CHECK(!parseProject("hello").ok);
    CHECK(!parseProject("GDMOTION 2\n").ok);
    CHECK(!parseProject("GDMOTION 1 extra\n").ok);
    CHECK(!parseProject("GDMOTION 1\nfps abc\n").ok);
    CHECK(!parseProject("GDMOTION 1\nfps 99999999999\n").ok);
    CHECK(!parseProject("GDMOTION 1\nfps 30 40\n").ok);
    CHECK(!parseProject("GDMOTION 1\nwhat 1\n").ok);
    CHECK(!parseProject("GDMOTION 1\nkey 0 1 linear\n").ok);
    CHECK(!parseProject("GDMOTION 1\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 posx\nkey 0 1 linear\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 posx\ntrack 2 5 posx\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 sideways\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 posx\nkey 0 1 wobbly\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 posx\nkey 0 nan linear\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 5 posx\nkey 5 1 linear\nkey 5 2 linear\nend\n").ok);
    CHECK(!parseProject("GDMOTION 1\ntrack 1 0 posx\nend\n").ok);  // group 0
    CHECK(parseProject("GDMOTION 1\nname x\nfps 60\nlength 10\ntrack 1 5 posx\nkey 0 1 linear\nend\n").ok);
    const ParseResult bad = parseProject("GDMOTION 1\nwhat 1\n");
    CHECK(bad.error.find("line 2") != std::string::npos);
}

static void testTimeline() {
    TimelineView v;
    v.scrollFrame = 10.0;
    v.pixelsPerFrame = 8.0;
    v.widthPx = 480.0;
    CHECK(approx(frameToX(v, 10.0), 0.0, 1e-12));
    CHECK(approx(frameToX(v, 11.0), 8.0, 1e-12));
    CHECK(approx(xToFrame(v, frameToX(v, 37.25)), 37.25, 1e-9));
    CHECK(approx(visibleFrames(v), 60.0, 1e-12));

    // zoom keeps the frame under the finger
    const int32_t length = 1000;
    TimelineView z;
    z.scrollFrame = 100.0;
    z.pixelsPerFrame = 8.0;
    z.widthPx = 480.0;
    const double anchorX = 200.0;
    const double before = xToFrame(z, anchorX);
    zoomAt(z, anchorX, 2.0, length);
    CHECK(approx(z.pixelsPerFrame, 16.0, 1e-12));
    CHECK(approx(xToFrame(z, anchorX), before, 1e-9));
    zoomAt(z, anchorX, 0.5, length);
    CHECK(approx(xToFrame(z, anchorX), before, 1e-9));

    // zoom limits
    for (int i = 0; i < 20; ++i) zoomAt(z, anchorX, 2.0, length);
    CHECK(approx(z.pixelsPerFrame, kMaxPixelsPerFrame, 1e-12));
    for (int i = 0; i < 20; ++i) zoomAt(z, anchorX, 0.5, length);
    CHECK(approx(z.pixelsPerFrame, kMinPixelsPerFrame, 1e-12));

    // scroll limits
    TimelineView s;
    s.pixelsPerFrame = 10.0;
    s.widthPx = 500.0;  // 50 frames visible
    scrollByPixels(s, -9999.0, length);
    CHECK(approx(s.scrollFrame, 0.0, 1e-12));
    scrollByPixels(s, 99999999.0, length);
    CHECK(approx(s.scrollFrame, 950.0, 1e-9));
    scrollByPixels(s, std::nan(""), length);
    CHECK(approx(s.scrollFrame, 950.0, 1e-9));

    // short project: cannot scroll at all
    TimelineView t;
    t.pixelsPerFrame = 10.0;
    t.widthPx = 500.0;
    scrollByPixels(t, 1000.0, 20);
    CHECK(approx(t.scrollFrame, 0.0, 1e-12));

    CHECK(nearestFrame(2.4) == 2);
    CHECK(nearestFrame(2.5) == 3);
    CHECK(nearestFrame(-2.4) == -2);
    CHECK(nearestFrame(std::nan("")) == 0);
    CHECK(nearestFrame(1e30) == 2147483647);
    CHECK(nearestFrame(-1e30) == -2147483647 - 1);
}

static void testSelfCheck() {
    const std::string problem = runSelfCheck();
    if (!problem.empty()) std::printf("self check said: %s\n", problem.c_str());
    CHECK(problem.empty());
}

int main() {
    testEasingBasics();
    testEasingShape();
    testKeysAndEvaluate();
    testValidate();
    testBake();
    testBakeMatchesEvaluate();
    testSerialize();
    testTimeline();
    testFollowFrame();
    testSelectionGroups();
    testSelfCheck();
    std::printf("%d checks, %d failed\n", g_checks, g_failed);
    return g_failed == 0 ? 0 : 1;
}
