// Runs the real TimelineBar code against the MOCK SDK (tests/mock_sdk).
// This checks my own logic (buttons, playhead, keys). It does not prove the
// code compiles against the real Geode SDK.
// Run with:  sh tests/run_tests.sh   (from the project root)
#include <cmath>
#include <cstdio>

#include "../src/editor/TimelineBar.hpp"
#include "check.hpp"

using namespace gdm;

static CCMenuItemSpriteExtra* findButton(cocos2d::CCNode* node, int tag) {
    CCMenuItemSpriteExtra* item = dynamic_cast<CCMenuItemSpriteExtra*>(node);
    if (item && item->getTag() == tag) return item;
    for (size_t i = 0; i < node->children.size(); ++i) {
        CCMenuItemSpriteExtra* found = findButton(node->children[i], tag);
        if (found) return found;
    }
    return nullptr;
}

static int countButtons(cocos2d::CCNode* node) {
    int n = dynamic_cast<CCMenuItemSpriteExtra*>(node) ? 1 : 0;
    for (size_t i = 0; i < node->children.size(); ++i) n += countButtons(node->children[i]);
    return n;
}

static void press(TimelineBar* bar, int tag, int times = 1) {
    CCMenuItemSpriteExtra* b = findButton(bar, tag);
    CHECK(b != nullptr);
    if (!b) return;
    for (int i = 0; i < times; ++i) b->activate();
}

static bool playheadVisible(TimelineBar* bar) {
    const double x = frameToX(bar->view(), static_cast<double>(bar->playhead()));
    return x >= 0.0 && x <= bar->view().widthPx;
}

int main() {
    TimelineBar* bar = TimelineBar::create(569.f);
    CHECK(bar != nullptr);
    if (!bar) return 1;
    CHECK(countButtons(bar) == 11);
    CHECK(bar->playhead() == 0 && bar->group() == 1 && bar->project().tracks.empty());
    CHECK(!bar->message().empty());

    // playhead moves and clamps
    press(bar, TimelineBar::kForward10, 3);
    CHECK(bar->playhead() == 30);
    press(bar, TimelineBar::kBack1);
    CHECK(bar->playhead() == 29);
    press(bar, TimelineBar::kBack10, 10);
    CHECK(bar->playhead() == 0);
    press(bar, TimelineBar::kForward10, 100);
    CHECK(bar->playhead() == bar->project().lengthFrames);
    CHECK(playheadVisible(bar));
    press(bar, TimelineBar::kBack10, 100);
    CHECK(bar->playhead() == 0 && playheadVisible(bar));

    // zoom keeps the playhead in view and stays inside the limits
    press(bar, TimelineBar::kForward10, 12);
    press(bar, TimelineBar::kZoomIn, 12);
    CHECK(approx(bar->view().pixelsPerFrame, kMaxPixelsPerFrame, 1e-9));
    CHECK(playheadVisible(bar));
    press(bar, TimelineBar::kZoomOut, 40);
    CHECK(approx(bar->view().pixelsPerFrame, kMinPixelsPerFrame, 1e-9));
    CHECK(playheadVisible(bar));
    press(bar, TimelineBar::kScrollLeft, 5);
    press(bar, TimelineBar::kScrollRight, 5);
    CHECK(bar->view().scrollFrame >= 0.0);

    // group buttons
    press(bar, TimelineBar::kGroupDown, 3);
    CHECK(bar->group() == 1);
    press(bar, TimelineBar::kGroupUp, 3);
    CHECK(bar->group() == 4);

    // keys: add, replace, delete
    press(bar, TimelineBar::kBack10, 100);
    press(bar, TimelineBar::kForward10, 3);  // frame 30
    bar->addPositionKey(100.0, 200.0);
    CHECK(bar->project().tracks.size() == 2);
    press(bar, TimelineBar::kForward10, 3);  // frame 60
    bar->addPositionKey(150.0, 250.0);
    bar->addPositionKey(160.0, 260.0);       // same frame: replaces
    CHECK(bar->project().tracks[0].keys.size() == 2);
    CHECK(bar->project().tracks[1].keys.size() == 2);
    CHECK(bar->project().tracks[0].keys[1].value == 160.0);
    CHECK(bar->project().tracks[0].group == 4);
    CHECK(validateProject(bar->project()).empty());
    press(bar, TimelineBar::kDeleteKey);
    CHECK(bar->project().tracks[0].keys.size() == 1 && bar->project().tracks[1].keys.size() == 1);
    press(bar, TimelineBar::kDeleteKey);  // nothing left on this frame
    CHECK(bar->message().find("No key") != std::string::npos);

    // other group gets its own tracks
    press(bar, TimelineBar::kGroupUp);
    bar->addPositionKey(1.0, 2.0);
    CHECK(bar->project().tracks.size() == 4);
    CHECK(validateProject(bar->project()).empty());

    // bad input is refused without changing anything
    const size_t before = bar->project().tracks.size();
    bar->addPositionKey(std::nan(""), 0.0);
    CHECK(bar->project().tracks.size() == before);
    CHECK(bar->message().find("usable") != std::string::npos);

    std::printf("%d checks, %d failed\n", g_checks, g_failed);
    return g_failed == 0 ? 0 : 1;
}
