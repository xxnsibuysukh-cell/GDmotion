// Easing tests (pure C++, no Geode SDK needed). Part of the test_core program.
#include <cmath>
#include <vector>

#include "Easing.hpp"
#include "check.hpp"

using namespace gdm;

static EasingType easingAt(int i) { return static_cast<EasingType>(i); }

void testEasingBasics() {
    for (int i = 0; i < kEasingCount; ++i) {
        const EasingType e = easingAt(i);
        CHECK(approx(applyEasing(e, 0.0), 0.0, 1e-9));
        CHECK(approx(applyEasing(e, 1.0), 1.0, 1e-9));
        CHECK(std::isfinite(applyEasing(e, 0.37)));
        CHECK(approx(applyEasing(e, -5.0), 0.0, 1e-9));  // clamped
        CHECK(approx(applyEasing(e, 7.0), 1.0, 1e-9));   // clamped
        CHECK(approx(applyEasing(e, std::nan("")), 0.0, 1e-9));
        // id and name round trips
        EasingType back = EasingType::Linear;
        CHECK(easingFromId(easingToId(e), back) && back == e);
        CHECK(easingFromName(easingName(e), back) && back == e);
    }
    EasingType tmp = EasingType::Linear;
    CHECK(!easingFromId(-1, tmp));
    CHECK(!easingFromId(kEasingCount, tmp));
    CHECK(!easingFromName("nonsense", tmp));
    CHECK(approx(applyEasing(EasingType::Linear, 0.25), 0.25, 1e-12));
    CHECK(approx(applyEasing(EasingType::EaseIn, 0.5), 0.25, 1e-12));
    CHECK(approx(applyEasing(EasingType::EaseOut, 0.25), 0.5, 1e-12));
    CHECK(approx(applyEasing(EasingType::EaseInOut, 0.5), 0.5, 1e-12));
    CHECK(approx(applyEasing(EasingType::SineInOut, 0.5), 0.5, 1e-12));
    CHECK(approx(applyEasing(EasingType::ExponentialInOut, 0.5), 0.5, 1e-12));
}

static void rangeOf(EasingType e, double& lo, double& hi) {
    lo = 0.0;
    hi = 1.0;
    for (int i = 0; i <= 1000; ++i) {
        const double v = applyEasing(e, i / 1000.0);
        if (v < lo) lo = v;
        if (v > hi) hi = v;
    }
}

void testEasingShape() {
    // These types must never go backwards and never leave [0, 1].
    const EasingType calm[] = {
        EasingType::Linear, EasingType::EaseInOut, EasingType::EaseIn, EasingType::EaseOut,
        EasingType::ExponentialInOut, EasingType::ExponentialIn, EasingType::ExponentialOut,
        EasingType::SineInOut, EasingType::SineIn, EasingType::SineOut};
    for (size_t k = 0; k < sizeof(calm) / sizeof(calm[0]); ++k) {
        double prev = applyEasing(calm[k], 0.0);
        for (int i = 1; i <= 1000; ++i) {
            const double v = applyEasing(calm[k], i / 1000.0);
            CHECK(v >= prev - 1e-12);
            CHECK(v >= -1e-9 && v <= 1.0 + 1e-9);
            prev = v;
        }
    }
    // Overshooting types really overshoot.
    double lo = 0.0, hi = 1.0;
    rangeOf(EasingType::BackIn, lo, hi);
    CHECK(lo < -0.05);
    rangeOf(EasingType::BackOut, lo, hi);
    CHECK(hi > 1.05);
    rangeOf(EasingType::ElasticIn, lo, hi);
    CHECK(lo < -0.05);
    rangeOf(EasingType::ElasticOut, lo, hi);
    CHECK(hi > 1.05);
    // Bounce stays inside [0, 1].
    for (int i = 0; i <= 1000; ++i) {
        const double v = applyEasing(EasingType::BounceOut, i / 1000.0);
        CHECK(v >= -1e-9 && v <= 1.0 + 1e-9);
    }
}
