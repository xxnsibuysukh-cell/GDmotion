Reserved for sprites and other resources used by later phases.
Nothing in this folder is packed into the mod yet.
