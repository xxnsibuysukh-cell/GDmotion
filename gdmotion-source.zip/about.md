# GDmotion

Make animations for Geometry Dash without leaving the level editor.

## Status

**v0.1.0 is the foundation only.** It loads, checks that its animation engine works on your device, and writes the result to the Geode log. There is nothing to click yet.

## Planned

- An animation mode inside the editor itself, with a timeline you can scroll left and right.
- Keyframes on groups (position, rotation, scale, opacity) with all the Geometry Dash easings.
- Selecting an object that shares a group selects the whole group.
- Turning an animation into real triggers.
- Exporting a video (on PC with your own ffmpeg, on Android through the ffmpeg mod).
