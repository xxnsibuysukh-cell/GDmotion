# GDmotion

Make animations for Geometry Dash without leaving the level editor.

## Status

**v0.2.0 is an early preview.** Open a level in the editor and press **Anim** to show the timeline at the bottom. Move the playhead, zoom, pick a group number, select an object and press **Key** to record its position. Nothing is saved yet and no triggers are created yet.

## Planned

- Selecting an object that shares a group selects the whole group.
- Turning an animation into real triggers, saving projects, undo and a preview.
- Exporting a video (on PC with your own ffmpeg, on Android through the ffmpeg mod).
