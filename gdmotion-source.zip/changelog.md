# GDmotion Changelog

## v0.2.0

- First editor features: an "Anim" button in the level editor opens a timeline bar at the bottom.
- Timeline: move the playhead (|< < > >|), zoom (Z+ Z-), scroll (<< >>), choose the group (G- G+).
- "Key" stores the selected object's position as keyframes for the chosen group; "Del" removes them. The animation lives in memory only for now (no saving yet).
- Selecting an object does not select its whole group yet (logic written and tested, not connected to the editor).

## v0.1.0

- First build: project setup, animation engine (easing, keyframes, baking, saving and loading) and a self-check that runs when the game starts.
