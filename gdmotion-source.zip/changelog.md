# GDmotion Changelog

## v0.1.0

- First build: project setup, animation engine (easing, keyframes, baking, saving and loading) and a self-check that runs when the game starts.
