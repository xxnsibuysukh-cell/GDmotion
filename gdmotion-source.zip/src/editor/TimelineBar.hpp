#pragma once

#include <Geode/Geode.hpp>

#include <cstdint>
#include <string>

#include "../core/Project.hpp"
#include "../core/Timeline.hpp"

namespace gdm {

// Small rectangular text button (coloured background + label) for menus.
// Returns nullptr if the nodes could not be created.
CCMenuItemSpriteExtra* makeTextButton(const char* text, float width, cocos2d::CCObject* target,
                                      cocos2d::SEL_MenuHandler callback);

// The animation timeline shown at the bottom of the editor.
// Phase 2: the animation lives in memory only (saving comes in Phase 3).
class TimelineBar : public cocos2d::CCNode {
public:
    enum Action : int {
        kBack10 = 1,
        kBack1 = 2,
        kForward1 = 3,
        kForward10 = 4,
        kZoomIn = 5,
        kZoomOut = 6,
        kScrollLeft = 7,
        kScrollRight = 8,
        kGroupDown = 9,
        kGroupUp = 10,
        kDeleteKey = 11
    };

    static TimelineBar* create(float width);
    static float barHeight();

    // Sets X and Y keys for the current group at the playhead.
    void addPositionKey(double x, double y);
    void showMessage(const std::string& text);

    const Project& project() const { return m_project; }
    int32_t playhead() const { return m_playhead; }
    int32_t group() const { return m_group; }
    const std::string& message() const { return m_message; }
    const TimelineView& view() const { return m_view; }

private:
    bool init(float width);
    void onButton(cocos2d::CCObject* sender);
    void movePlayhead(int32_t delta);
    void deleteKeysAtPlayhead();
    int findOrCreateTrack(Property prop);
    bool setKey(Property prop, double value);
    void rebuild();
    void drawRuler();
    void drawRow(float y, const char* name, Property prop);
    void drawPlayhead();
    void drawStatus();

    Project m_project;
    TimelineView m_view;
    int32_t m_playhead = 0;
    int32_t m_group = 1;
    float m_width = 0.f;
    std::string m_message;
    // Child of this node, owned by it (never removed), rebuilt on every change.
    cocos2d::CCNode* m_content = nullptr;
};

}  // namespace gdm
