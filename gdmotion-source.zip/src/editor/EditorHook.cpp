#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>

#include "TimelineBar.hpp"

using namespace geode::prelude;

namespace {

// Where things sit on screen. If something overlaps editor buttons, change
// only these three numbers.
const float kBarY = 90.f;
const float kMenuRightMargin = 34.f;
const float kMenuHeightFraction = 0.62f;

}  // namespace

// Phase 2: one hook, EditorUI::init, adds an "Anim" button (and a "Key" button
// that appears in animation mode) plus the timeline bar.
//
// TODO (Phase 2b, not done): selecting one object selects its whole group.
// The pure logic exists and is tested (gdm::expandSelectionByGroups), but it is
// NOT wired in, because these still have to be checked against the bindings
// for both platforms: how a GameObject exposes its group ids, and which
// EditorUI selection function a tap uses (and how to avoid re-entering it).
class $modify(GdmEditorUI, EditorUI) {
    bool init(LevelEditorLayer* layer) {
        if (!EditorUI::init(layer)) return false;
        try {
            this->gdmAddUi();
        } catch (...) {
            log::error("GDmotion: could not add the editor UI");
        }
        return true;
    }

    void gdmAddUi() {
        const CCSize win = CCDirector::sharedDirector()->getWinSize();

        gdm::TimelineBar* bar = gdm::TimelineBar::create(win.width);
        if (!bar) return;
        bar->setID("timeline"_spr);
        bar->setPosition(CCPoint(0.f, kBarY));
        bar->setVisible(false);
        this->addChild(bar, 50);

        CCMenu* menu = CCMenu::create();
        if (!menu) return;
        menu->setID("menu"_spr);
        menu->setPosition(CCPoint(win.width - kMenuRightMargin, win.height * kMenuHeightFraction));

        CCMenuItemSpriteExtra* toggle =
            gdm::makeTextButton("Anim", 44.f, this, menu_selector(GdmEditorUI::onGdmToggle));
        if (toggle) {
            toggle->setID("toggle"_spr);
            toggle->setPosition(CCPoint(0.f, 12.f));
            menu->addChild(toggle);
        }

        CCMenuItemSpriteExtra* key =
            gdm::makeTextButton("Key", 44.f, this, menu_selector(GdmEditorUI::onGdmKey));
        if (key) {
            key->setID("key"_spr);
            key->setPosition(CCPoint(0.f, -12.f));
            key->setVisible(false);
            key->setEnabled(false);
            menu->addChild(key);
        }
        this->addChild(menu, 50);
    }

    void onGdmToggle(CCObject*) {
        try {
            CCNode* bar = this->getChildByID("timeline"_spr);
            if (!bar) return;
            const bool show = !bar->isVisible();
            bar->setVisible(show);

            CCNode* menu = this->getChildByID("menu"_spr);
            if (!menu) return;
            CCMenuItemSpriteExtra* key = static_cast<CCMenuItemSpriteExtra*>(menu->getChildByID("key"_spr));
            if (key) {
                key->setVisible(show);
                key->setEnabled(show);
            }
        } catch (...) {
            log::error("GDmotion: toggle failed");
        }
    }

    void onGdmKey(CCObject*) {
        try {
            gdm::TimelineBar* bar = static_cast<gdm::TimelineBar*>(this->getChildByID("timeline"_spr));
            if (!bar) return;

            GameObject* object = m_selectedObject;
            if (!object && m_selectedObjects && m_selectedObjects->count() > 0) {
                object = static_cast<GameObject*>(m_selectedObjects->objectAtIndex(0));
            }
            if (!object) {
                bar->showMessage("Select an object first");
                return;
            }
            bar->addPositionKey(static_cast<double>(object->getPositionX()),
                                static_cast<double>(object->getPositionY()));
        } catch (...) {
            log::error("GDmotion: key button failed");
        }
    }
};
