#include "TimelineBar.hpp"

#include <cmath>
#include <cstdio>
#include <new>

using namespace geode::prelude;

namespace gdm {
namespace {

const float kBarHeight = 100.f;
const float kTrackLeft = 30.f;
const float kRightPad = 8.f;
const float kButtonWidth = 34.f;
const float kButtonGap = 4.f;
const float kButtonRowY = 86.f;
const float kStatusY = 68.f;
const float kMessageY = 57.f;
const float kRulerLabelY = 47.f;
const float kRulerLineY = 38.f;
const float kRowXY = 27.f;
const float kRowYY = 13.f;
const double kZoomFactor = 1.5;
const double kMinTickPixels = 36.0;
const int kMaxTicks = 400;

void addRect(CCNode* parent, float x, float y, float w, float h, const ccColor4B& color) {
    CCLayerColor* rect = CCLayerColor::create(color, w, h);
    if (!rect) return;
    rect->setPosition(CCPoint(x, y));
    parent->addChild(rect);
}

void addLabel(CCNode* parent, const std::string& text, float x, float y, float scale) {
    CCLabelBMFont* label = CCLabelBMFont::create(text.c_str(), "bigFont.fnt");
    if (!label) return;
    label->setScale(scale);
    label->setAnchorPoint(CCPoint(0.f, 0.5f));
    label->setPosition(CCPoint(x, y));
    parent->addChild(label);
}

int chooseTickStep(double pixelsPerFrame) {
    static const int steps[] = {1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1200};
    const int count = static_cast<int>(sizeof(steps) / sizeof(steps[0]));
    for (int i = 0; i < count; ++i) {
        if (static_cast<double>(steps[i]) * pixelsPerFrame >= kMinTickPixels) return steps[i];
    }
    return steps[count - 1];
}

}  // namespace

CCMenuItemSpriteExtra* makeTextButton(const char* text, float width, CCObject* target,
                                      SEL_MenuHandler callback) {
    CCLayerColor* background = CCLayerColor::create(ccc4(40, 70, 140, 235), width, 18.f);
    if (!background) return nullptr;
    background->ignoreAnchorPointForPosition(false);
    CCLabelBMFont* label = CCLabelBMFont::create(text, "bigFont.fnt");
    if (label) {
        label->setScale(0.32f);
        label->setPosition(CCPoint(width / 2.f, 9.f));
        background->addChild(label);
    }
    return CCMenuItemSpriteExtra::create(background, target, callback);
}

TimelineBar* TimelineBar::create(float width) {
    TimelineBar* bar = new (std::nothrow) TimelineBar();
    if (bar && bar->init(width)) {
        bar->autorelease();
        return bar;
    }
    CC_SAFE_DELETE(bar);
    return nullptr;
}

float TimelineBar::barHeight() { return kBarHeight; }

bool TimelineBar::init(float width) {
    if (!CCNode::init()) return false;
    m_width = width;
    this->setContentSize(CCSize(width, kBarHeight));

    CCLayerColor* background = CCLayerColor::create(ccc4(0, 0, 0, 190), width, kBarHeight);
    if (!background) return false;
    this->addChild(background);

    m_view.pixelsPerFrame = 8.0;
    m_view.widthPx = static_cast<double>(width - kTrackLeft - kRightPad);
    clampView(m_view, m_project.lengthFrames);

    m_content = CCNode::create();
    if (!m_content) return false;
    this->addChild(m_content);

    CCMenu* menu = CCMenu::create();
    if (!menu) return false;
    menu->setPosition(CCPoint(0.f, 0.f));
    this->addChild(menu);

    struct ButtonDef {
        const char* text;
        int action;
    };
    const ButtonDef defs[] = {
        {"|<", kBack10},       {"<", kBack1},        {">", kForward1},       {">|", kForward10},
        {"Z+", kZoomIn},       {"Z-", kZoomOut},     {"<<", kScrollLeft},    {">>", kScrollRight},
        {"G-", kGroupDown},    {"G+", kGroupUp},     {"Del", kDeleteKey}};
    const int count = static_cast<int>(sizeof(defs) / sizeof(defs[0]));

    float x = 8.f + kButtonWidth / 2.f;
    for (int i = 0; i < count; ++i) {
        CCMenuItemSpriteExtra* item =
            makeTextButton(defs[i].text, kButtonWidth, this, menu_selector(TimelineBar::onButton));
        if (!item) continue;
        item->setTag(defs[i].action);
        item->setPosition(CCPoint(x, kButtonRowY));
        menu->addChild(item);
        x += kButtonWidth + kButtonGap;
    }

    m_message = "Select an object, then press Key";
    rebuild();
    return true;
}

void TimelineBar::showMessage(const std::string& text) {
    m_message = text;
    rebuild();
}

void TimelineBar::movePlayhead(int32_t delta) {
    int64_t value = static_cast<int64_t>(m_playhead) + static_cast<int64_t>(delta);
    if (value < 0) value = 0;
    if (value > static_cast<int64_t>(m_project.lengthFrames)) value = m_project.lengthFrames;
    m_playhead = static_cast<int32_t>(value);
    followFrame(m_view, static_cast<double>(m_playhead), m_project.lengthFrames);
}

int TimelineBar::findOrCreateTrack(Property prop) {
    for (size_t i = 0; i < m_project.tracks.size(); ++i) {
        if (m_project.tracks[i].group == m_group && m_project.tracks[i].prop == prop) {
            return static_cast<int>(i);
        }
    }
    if (m_project.tracks.size() >= static_cast<size_t>(kMaxTracks)) return -1;

    int32_t nextId = 1;
    for (size_t i = 0; i < m_project.tracks.size(); ++i) {
        if (m_project.tracks[i].id >= nextId) nextId = m_project.tracks[i].id + 1;
    }
    Track track;
    track.id = nextId;
    track.group = m_group;
    track.prop = prop;
    m_project.tracks.push_back(track);
    return static_cast<int>(m_project.tracks.size()) - 1;
}

bool TimelineBar::setKey(Property prop, double value) {
    const int index = findOrCreateTrack(prop);
    if (index < 0) return false;
    Track& track = m_project.tracks[static_cast<size_t>(index)];

    Keyframe key;
    key.frame = m_playhead;
    key.value = value;
    key.easing = EasingType::Linear;

    bool replacing = false;
    for (size_t i = 0; i < track.keys.size(); ++i) {
        if (track.keys[i].frame == m_playhead) {
            key.easing = track.keys[i].easing;  // keep the curve of the key being replaced
            replacing = true;
            break;
        }
    }
    if (!replacing && track.keys.size() >= static_cast<size_t>(kMaxKeysPerTrack)) return false;
    addKey(track, key);
    return true;
}

void TimelineBar::addPositionKey(double x, double y) {
    if (!std::isfinite(x) || !std::isfinite(y)) {
        showMessage("That object has no usable position");
        return;
    }
    if (!setKey(Property::PosX, x) || !setKey(Property::PosY, y)) {
        showMessage("Too many tracks or keys");
        return;
    }
    char text[128];
    std::snprintf(text, sizeof(text), "Key set: frame %d, group %d, x %.1f, y %.1f",
                  static_cast<int>(m_playhead), static_cast<int>(m_group), x, y);
    showMessage(text);
}

void TimelineBar::deleteKeysAtPlayhead() {
    int removed = 0;
    for (size_t i = 0; i < m_project.tracks.size(); ++i) {
        if (m_project.tracks[i].group != m_group) continue;
        if (removeKey(m_project.tracks[i], m_playhead)) ++removed;
    }
    m_message = removed > 0 ? "Key deleted" : "No key at this frame for this group";
}

void TimelineBar::onButton(CCObject* sender) {
    try {
        CCNode* node = static_cast<CCNode*>(sender);
        if (!node) return;
        const int32_t length = m_project.lengthFrames;
        m_message.clear();

        switch (node->getTag()) {
            case kBack10: movePlayhead(-10); break;
            case kBack1: movePlayhead(-1); break;
            case kForward1: movePlayhead(1); break;
            case kForward10: movePlayhead(10); break;
            case kZoomIn:
                zoomAt(m_view, frameToX(m_view, static_cast<double>(m_playhead)), kZoomFactor, length);
                break;
            case kZoomOut:
                zoomAt(m_view, frameToX(m_view, static_cast<double>(m_playhead)), 1.0 / kZoomFactor, length);
                break;
            case kScrollLeft: scrollByPixels(m_view, -m_view.widthPx * 0.5, length); break;
            case kScrollRight: scrollByPixels(m_view, m_view.widthPx * 0.5, length); break;
            case kGroupDown:
                if (m_group > 1) --m_group;
                break;
            case kGroupUp:
                if (m_group < kMaxGroupId) ++m_group;
                break;
            case kDeleteKey: deleteKeysAtPlayhead(); break;
            default: break;
        }
        rebuild();
    } catch (...) {
        log::error("GDmotion: timeline button failed");
    }
}

void TimelineBar::rebuild() {
    if (!m_content) return;
    m_content->removeAllChildrenWithCleanup(true);
    clampView(m_view, m_project.lengthFrames);
    drawRuler();
    drawRow(kRowXY, "X", Property::PosX);
    drawRow(kRowYY, "Y", Property::PosY);
    drawPlayhead();
    drawStatus();
}

void TimelineBar::drawRuler() {
    const int step = chooseTickStep(m_view.pixelsPerFrame);
    const double first = std::ceil(m_view.scrollFrame / static_cast<double>(step)) * static_cast<double>(step);
    const double last = m_view.scrollFrame + visibleFrames(m_view);
    int guard = 0;
    for (double frame = first; frame <= last && guard < kMaxTicks; frame += static_cast<double>(step), ++guard) {
        const float x = kTrackLeft + static_cast<float>(frameToX(m_view, frame));
        addRect(m_content, x, kRulerLineY, 1.f, 6.f, ccc4(120, 140, 200, 255));
        addLabel(m_content, std::to_string(static_cast<long long>(frame)), x + 2.f, kRulerLabelY, 0.22f);
    }
}

void TimelineBar::drawRow(float y, const char* name, Property prop) {
    addRect(m_content, kTrackLeft, y - 0.5f, static_cast<float>(m_view.widthPx), 1.f, ccc4(70, 90, 150, 255));
    addLabel(m_content, name, 8.f, y, 0.3f);

    const float minX = kTrackLeft - 3.f;
    const float maxX = m_width - kRightPad + 3.f;
    for (size_t t = 0; t < m_project.tracks.size(); ++t) {
        const Track& track = m_project.tracks[t];
        if (track.group != m_group || track.prop != prop) continue;
        for (size_t k = 0; k < track.keys.size(); ++k) {
            const float x = kTrackLeft + static_cast<float>(frameToX(m_view, static_cast<double>(track.keys[k].frame)));
            if (x < minX || x > maxX) continue;
            addRect(m_content, x - 3.f, y - 3.f, 6.f, 6.f, ccc4(255, 205, 60, 255));
        }
    }
}

void TimelineBar::drawPlayhead() {
    const float x = kTrackLeft + static_cast<float>(frameToX(m_view, static_cast<double>(m_playhead)));
    if (x < kTrackLeft - 1.f || x > m_width - kRightPad + 1.f) return;
    addRect(m_content, x - 1.f, 6.f, 2.f, 46.f, ccc4(60, 235, 255, 255));
}

void TimelineBar::drawStatus() {
    char text[128];
    std::snprintf(text, sizeof(text), "Frame %d/%d   Group %d   Zoom %.1f px/frame",
                  static_cast<int>(m_playhead), static_cast<int>(m_project.lengthFrames),
                  static_cast<int>(m_group), m_view.pixelsPerFrame);
    addLabel(m_content, text, 8.f, kStatusY, 0.3f);
    if (!m_message.empty()) addLabel(m_content, m_message, 8.f, kMessageY, 0.26f);
}

}  // namespace gdm
