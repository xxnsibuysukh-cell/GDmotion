#include <Geode/Geode.hpp>

#include <string>

#include "core/SelfCheck.hpp"

using namespace geode::prelude;

// Proves at startup that the animation core works on this device. The editor
// features live in src/editor.
$execute {
    try {
        const std::string problem = gdm::runSelfCheck();
        if (problem.empty()) {
            log::info("GDmotion core self-check passed");
        } else {
            log::warn("GDmotion core self-check FAILED: {}", problem);
        }
    } catch (...) {
        log::error("GDmotion core self-check threw an exception");
    }
}
