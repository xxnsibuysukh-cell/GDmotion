#include <Geode/Geode.hpp>

#include <string>

#include "core/SelfCheck.hpp"

using namespace geode::prelude;

// Phase 1: the mod only proves that the animation core loads and works on this
// device. Editor hooks and the timeline arrive in Phase 2.
$execute {
    try {
        const std::string problem = gdm::runSelfCheck();
        if (problem.empty()) {
            log::info("GDmotion core self-check passed");
        } else {
            log::warn("GDmotion core self-check FAILED: {}", problem);
        }
    } catch (...) {
        log::error("GDmotion core self-check threw an exception");
    }
}
