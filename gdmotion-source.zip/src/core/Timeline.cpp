#include "Timeline.hpp"

#include <cmath>
#include <limits>

namespace gdm {
namespace {

const double kDefaultPixelsPerFrame = 8.0;

}  // namespace

double frameToX(const TimelineView& view, double frame) {
    return (frame - view.scrollFrame) * view.pixelsPerFrame;
}

double xToFrame(const TimelineView& view, double x) {
    if (!(view.pixelsPerFrame > 0.0)) return view.scrollFrame;
    return view.scrollFrame + x / view.pixelsPerFrame;
}

double visibleFrames(const TimelineView& view) {
    if (!(view.pixelsPerFrame > 0.0)) return 0.0;
    return view.widthPx / view.pixelsPerFrame;
}

void clampView(TimelineView& view, int32_t lengthFrames) {
    if (!std::isfinite(view.pixelsPerFrame)) view.pixelsPerFrame = kDefaultPixelsPerFrame;
    if (view.pixelsPerFrame < kMinPixelsPerFrame) view.pixelsPerFrame = kMinPixelsPerFrame;
    if (view.pixelsPerFrame > kMaxPixelsPerFrame) view.pixelsPerFrame = kMaxPixelsPerFrame;
    if (!std::isfinite(view.widthPx) || view.widthPx < 1.0) view.widthPx = 1.0;

    double maxScroll = static_cast<double>(lengthFrames) - visibleFrames(view);
    if (!(maxScroll > 0.0)) maxScroll = 0.0;
    if (!std::isfinite(view.scrollFrame) || view.scrollFrame < 0.0) view.scrollFrame = 0.0;
    if (view.scrollFrame > maxScroll) view.scrollFrame = maxScroll;
}

void scrollByPixels(TimelineView& view, double dxPx, int32_t lengthFrames) {
    clampView(view, lengthFrames);
    if (std::isfinite(dxPx)) view.scrollFrame += dxPx / view.pixelsPerFrame;
    clampView(view, lengthFrames);
}

void zoomAt(TimelineView& view, double anchorXPx, double factor, int32_t lengthFrames) {
    clampView(view, lengthFrames);
    if (!std::isfinite(factor) || !(factor > 0.0)) return;
    if (!std::isfinite(anchorXPx)) anchorXPx = 0.0;

    const double anchorFrame = xToFrame(view, anchorXPx);
    view.pixelsPerFrame *= factor;
    clampView(view, lengthFrames);  // fixes zoom limits before the scroll is recomputed
    view.scrollFrame = anchorFrame - anchorXPx / view.pixelsPerFrame;
    clampView(view, lengthFrames);
}

int32_t nearestFrame(double frame) {
    if (!std::isfinite(frame)) return 0;
    const double rounded = std::floor(frame + 0.5);
    const double lo = static_cast<double>((std::numeric_limits<int32_t>::min)());
    const double hi = static_cast<double>((std::numeric_limits<int32_t>::max)());
    if (rounded < lo) return (std::numeric_limits<int32_t>::min)();
    if (rounded > hi) return (std::numeric_limits<int32_t>::max)();
    return static_cast<int32_t>(rounded);
}

}  // namespace gdm
