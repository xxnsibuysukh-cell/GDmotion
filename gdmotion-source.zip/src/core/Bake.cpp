#include "Bake.hpp"

#include <algorithm>
#include <cmath>

namespace gdm {
namespace {

const double kHoldEpsilon = 1e-9;

bool segmentLess(const BakedSegment& a, const BakedSegment& b) {
    if (a.startSec != b.startSec) return a.startSec < b.startSec;
    return a.trackId < b.trackId;
}

}  // namespace

double framesToSeconds(double frames, int32_t fps) {
    if (fps < 1) return 0.0;
    return frames / static_cast<double>(fps);
}

std::vector<BakedSegment> bakeTrack(const Track& track, int32_t fps) {
    std::vector<BakedSegment> out;
    if (fps < 1) return out;
    if (track.keys.size() < 2) return out;

    for (size_t i = 0; i + 1 < track.keys.size(); ++i) {
        const Keyframe& a = track.keys[i];
        const Keyframe& b = track.keys[i + 1];
        if (b.frame <= a.frame) continue;
        if (std::fabs(b.value - a.value) < kHoldEpsilon) continue;

        const double frameSpan = static_cast<double>(static_cast<int64_t>(b.frame) -
                                                     static_cast<int64_t>(a.frame));
        BakedSegment seg;
        seg.trackId = track.id;
        seg.group = track.group;
        seg.prop = track.prop;
        seg.startSec = framesToSeconds(static_cast<double>(a.frame), fps);
        seg.durationSec = framesToSeconds(frameSpan, fps);
        seg.from = a.value;
        seg.to = b.value;
        seg.easing = a.easing;
        out.push_back(seg);
    }
    return out;
}

std::vector<BakedSegment> bakeProject(const Project& project) {
    std::vector<BakedSegment> out;
    for (size_t i = 0; i < project.tracks.size(); ++i) {
        std::vector<BakedSegment> part = bakeTrack(project.tracks[i], project.fps);
        out.insert(out.end(), part.begin(), part.end());
    }
    std::stable_sort(out.begin(), out.end(), segmentLess);
    return out;
}

double sampleSegments(const std::vector<BakedSegment>& segments, double timeSec, double fallback) {
    if (segments.empty()) return fallback;
    if (!(timeSec > segments.front().startSec)) return segments.front().from;

    // Last segment that has started.
    const BakedSegment* current = &segments.front();
    for (size_t i = 0; i < segments.size(); ++i) {
        if (segments[i].startSec <= timeSec) current = &segments[i];
    }
    if (!(current->durationSec > 0.0)) return current->to;
    const double t = (timeSec - current->startSec) / current->durationSec;
    if (t >= 1.0) return current->to;
    return current->from + (current->to - current->from) * applyEasing(current->easing, t);
}

}  // namespace gdm
