#include "SelectionGroups.hpp"

#include <algorithm>

namespace gdm {

std::vector<size_t> expandSelectionByGroups(const std::vector<std::vector<int32_t> >& objectGroups,
                                            const std::vector<size_t>& selected) {
    std::vector<char> picked(objectGroups.size(), 0);
    std::vector<int32_t> groups;

    for (size_t i = 0; i < selected.size(); ++i) {
        const size_t index = selected[i];
        if (index >= objectGroups.size()) continue;
        picked[index] = 1;
        for (size_t g = 0; g < objectGroups[index].size(); ++g) {
            if (objectGroups[index][g] > 0) groups.push_back(objectGroups[index][g]);
        }
    }
    std::sort(groups.begin(), groups.end());
    groups.erase(std::unique(groups.begin(), groups.end()), groups.end());

    if (!groups.empty()) {
        for (size_t i = 0; i < objectGroups.size(); ++i) {
            for (size_t g = 0; g < objectGroups[i].size(); ++g) {
                if (std::binary_search(groups.begin(), groups.end(), objectGroups[i][g])) {
                    picked[i] = 1;
                    break;
                }
            }
        }
    }

    std::vector<size_t> result;
    for (size_t i = 0; i < picked.size(); ++i) {
        if (picked[i] != 0) result.push_back(i);
    }
    return result;
}

}  // namespace gdm
