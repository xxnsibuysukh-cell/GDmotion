#include "Project.hpp"

#include <algorithm>
#include <cmath>

namespace gdm {
namespace {

const char* const kPropertyNames[kPropertyCount] = {
    "posx", "posy", "rotation", "scalex", "scaley", "alpha"
};

std::string trackPrefix(const Track& track) {
    return "track " + std::to_string(track.id) + ": ";
}

}  // namespace

const char* propertyName(Property prop) {
    const int id = static_cast<int>(prop);
    if (id < 0 || id >= kPropertyCount) return kPropertyNames[0];
    return kPropertyNames[id];
}

bool propertyFromName(const std::string& name, Property& out) {
    for (int i = 0; i < kPropertyCount; ++i) {
        if (name == kPropertyNames[i]) {
            out = static_cast<Property>(i);
            return true;
        }
    }
    return false;
}

bool addKey(Track& track, const Keyframe& key) {
    std::vector<Keyframe>::iterator it = std::lower_bound(
        track.keys.begin(), track.keys.end(), key.frame,
        [](const Keyframe& k, int32_t frame) { return k.frame < frame; });
    if (it != track.keys.end() && it->frame == key.frame) {
        *it = key;
        return false;
    }
    track.keys.insert(it, key);
    return true;
}

bool removeKey(Track& track, int32_t frame) {
    for (std::vector<Keyframe>::iterator it = track.keys.begin(); it != track.keys.end(); ++it) {
        if (it->frame == frame) {
            track.keys.erase(it);
            return true;
        }
    }
    return false;
}

double evaluateTrack(const Track& track, double frame) {
    const std::vector<Keyframe>& keys = track.keys;
    if (keys.empty()) return 0.0;
    if (!(frame > static_cast<double>(keys.front().frame))) return keys.front().value;
    if (frame >= static_cast<double>(keys.back().frame)) return keys.back().value;

    std::vector<Keyframe>::const_iterator it = std::upper_bound(
        keys.begin(), keys.end(), frame,
        [](double f, const Keyframe& k) { return f < static_cast<double>(k.frame); });
    // frame is strictly inside (front, back), so `it` has a predecessor and is not end().
    const Keyframe& b = *it;
    const Keyframe& a = *(it - 1);
    const double span = static_cast<double>(b.frame) - static_cast<double>(a.frame);
    if (!(span > 0.0)) return a.value;
    const double t = (frame - static_cast<double>(a.frame)) / span;
    const double e = applyEasing(a.easing, t);
    return a.value + (b.value - a.value) * e;
}

std::string validateProject(const Project& project) {
    if (project.name.size() > static_cast<size_t>(kMaxNameLength)) return "name is too long";
    if (project.fps < kMinFps || project.fps > kMaxFps) return "fps is out of range";
    if (project.lengthFrames < 1 || project.lengthFrames > kMaxLengthFrames) {
        return "length is out of range";
    }
    if (project.tracks.size() > static_cast<size_t>(kMaxTracks)) return "too many tracks";

    for (size_t i = 0; i < project.tracks.size(); ++i) {
        const Track& track = project.tracks[i];
        if (track.id < 0) return trackPrefix(track) + "negative id";
        for (size_t j = 0; j < i; ++j) {
            if (project.tracks[j].id == track.id) return trackPrefix(track) + "duplicate id";
        }
        if (track.group < 1 || track.group > kMaxGroupId) {
            return trackPrefix(track) + "group is out of range";
        }
        const int prop = static_cast<int>(track.prop);
        if (prop < 0 || prop >= kPropertyCount) return trackPrefix(track) + "bad property";
        if (track.keys.size() > static_cast<size_t>(kMaxKeysPerTrack)) {
            return trackPrefix(track) + "too many keys";
        }
        for (size_t k = 0; k < track.keys.size(); ++k) {
            const Keyframe& key = track.keys[k];
            if (key.frame < 0 || key.frame > project.lengthFrames) {
                return trackPrefix(track) + "key frame is outside the project";
            }
            if (!std::isfinite(key.value)) return trackPrefix(track) + "key value is not finite";
            const int easing = static_cast<int>(key.easing);
            if (easing < 0 || easing >= kEasingCount) return trackPrefix(track) + "bad easing";
            if (k > 0 && key.frame <= track.keys[k - 1].frame) {
                return trackPrefix(track) + "keys must be in ascending frame order";
            }
        }
    }
    return std::string();
}

}  // namespace gdm
