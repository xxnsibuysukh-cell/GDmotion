#include "SelfCheck.hpp"

#include <cmath>

#include "Bake.hpp"
#include "Project.hpp"
#include "Serialize.hpp"

namespace gdm {

std::string runSelfCheck() {
    Project project;
    project.name = "self check";
    project.fps = 30;
    project.lengthFrames = 60;

    Track track;
    track.id = 1;
    track.group = 1;
    track.prop = Property::PosX;

    Keyframe a;
    a.frame = 0;
    a.value = 0.0;
    a.easing = EasingType::EaseOut;
    Keyframe b;
    b.frame = 30;
    b.value = 100.0;
    addKey(track, a);
    addKey(track, b);
    project.tracks.push_back(track);

    const std::string problem = validateProject(project);
    if (!problem.empty()) return "validate: " + problem;

    const double mid = evaluateTrack(project.tracks[0], 15.0);
    if (!(mid > 50.0 && mid < 100.0)) return "evaluate: ease-out midpoint is not between 50 and 100";

    const std::vector<BakedSegment> segments = bakeProject(project);
    if (segments.size() != 1) return "bake: expected exactly one segment";
    if (std::fabs(segments[0].durationSec - 1.0) > 1e-9) return "bake: duration should be 1 second";

    const std::string text = serializeProject(project);
    const ParseResult parsed = parseProject(text);
    if (!parsed.ok) return "load: " + parsed.error;
    if (serializeProject(parsed.project) != text) return "save/load: round trip changed the project";

    return std::string();
}

}  // namespace gdm
