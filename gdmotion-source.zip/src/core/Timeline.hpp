#pragma once

#include <cstdint>

namespace gdm {

// Pure math for a horizontally scrolling and zooming timeline.
// x is in pixels from the left edge of the timeline area.
struct TimelineView {
    double scrollFrame = 0.0;     // frame shown at the left edge
    double pixelsPerFrame = 8.0;  // zoom
    double widthPx = 480.0;       // width of the visible area
};

const double kMinPixelsPerFrame = 0.5;
const double kMaxPixelsPerFrame = 64.0;

double frameToX(const TimelineView& view, double frame);
double xToFrame(const TimelineView& view, double x);
double visibleFrames(const TimelineView& view);

// Forces zoom and scroll into valid ranges for a project of lengthFrames.
void clampView(TimelineView& view, int32_t lengthFrames);

// Positive dxPx moves the view toward later frames.
void scrollByPixels(TimelineView& view, double dxPx, int32_t lengthFrames);

// factor > 1 zooms in. The frame under anchorXPx stays under it (unless clamped).
void zoomAt(TimelineView& view, double anchorXPx, double factor, int32_t lengthFrames);

// Rounds to the nearest whole frame; non-finite input gives 0.
int32_t nearestFrame(double frame);

}  // namespace gdm
