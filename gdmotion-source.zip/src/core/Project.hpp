#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "Easing.hpp"

namespace gdm {

enum class Property : int {
    PosX = 0,
    PosY = 1,
    Rotation = 2,
    ScaleX = 3,
    ScaleY = 4,
    Alpha = 5
};

const int kPropertyCount = 6;

const char* propertyName(Property prop);
bool propertyFromName(const std::string& name, Property& out);

struct Keyframe {
    int32_t frame = 0;
    double value = 0.0;
    // Curve used from this key to the next key.
    EasingType easing = EasingType::Linear;
};

struct Track {
    int32_t id = 0;
    // Geometry Dash group id this track animates.
    int32_t group = 0;
    Property prop = Property::PosX;
    // Strictly ascending by frame.
    std::vector<Keyframe> keys;
};

struct Project {
    std::string name = "Untitled";
    int32_t fps = 30;
    int32_t lengthFrames = 300;
    std::vector<Track> tracks;
};

const int32_t kMinFps = 1;
const int32_t kMaxFps = 240;
const int32_t kMaxLengthFrames = 1000000;
const int32_t kMaxTracks = 2048;
const int32_t kMaxKeysPerTrack = 20000;
// Assumed upper bound for group ids; not checked against the game.
const int32_t kMaxGroupId = 9999;
const int32_t kMaxNameLength = 200;

// Inserts the key in frame order. Returns true if a new key was added,
// false if an existing key on the same frame was replaced.
bool addKey(Track& track, const Keyframe& key);

// Returns true if a key on that frame existed and was removed.
bool removeKey(Track& track, int32_t frame);

// Value of the track at a (possibly fractional) frame. Holds the first value
// before the first key and the last value after the last key. Empty track = 0.
double evaluateTrack(const Track& track, double frame);

// Returns an empty string when the project is valid, otherwise a short reason.
std::string validateProject(const Project& project);

}  // namespace gdm
