#pragma once

#include <cstdint>
#include <vector>

#include "Easing.hpp"
#include "Project.hpp"

namespace gdm {

// One animated move between two neighbouring keyframes of a track.
// Turning these into real Geometry Dash triggers is planned for Phase 3.
struct BakedSegment {
    int32_t trackId = 0;
    int32_t group = 0;
    Property prop = Property::PosX;
    double startSec = 0.0;
    double durationSec = 0.0;
    double from = 0.0;
    double to = 0.0;
    EasingType easing = EasingType::Linear;
};

// Returns 0 when fps < 1.
double framesToSeconds(double frames, int32_t fps);

// One segment per pair of neighbouring keys. Pairs whose values are equal
// (a "hold") produce no segment. Returns nothing when fps < 1.
std::vector<BakedSegment> bakeTrack(const Track& track, int32_t fps);

// All tracks, sorted by start time, then by track id.
std::vector<BakedSegment> bakeProject(const Project& project);

// Value of ONE track's segments at a time. Before the first segment it returns
// the first segment's start value; with no segments it returns fallback.
double sampleSegments(const std::vector<BakedSegment>& segments, double timeSec, double fallback);

}  // namespace gdm
