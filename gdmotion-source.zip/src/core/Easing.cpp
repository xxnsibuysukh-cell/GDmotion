#include "Easing.hpp"

#include <cmath>

namespace gdm {
namespace {

const double kPi = 3.14159265358979323846;
const double kRate = 2.0;
const double kBackS = 1.70158;

const char* const kNames[kEasingCount] = {
    "linear",
    "ease-in-out", "ease-in", "ease-out",
    "elastic-in-out", "elastic-in", "elastic-out",
    "bounce-in-out", "bounce-in", "bounce-out",
    "exponential-in-out", "exponential-in", "exponential-out",
    "sine-in-out", "sine-in", "sine-out",
    "back-in-out", "back-in", "back-out"
};

double clamp01(double t) {
    if (!(t > 0.0)) return 0.0;  // also catches NaN
    if (t > 1.0) return 1.0;
    return t;
}

double powIn(double t) { return std::pow(t, kRate); }

double powOut(double t) { return std::pow(t, 1.0 / kRate); }

double powInOut(double t) {
    t *= 2.0;
    if (t < 1.0) return 0.5 * std::pow(t, kRate);
    return 1.0 - 0.5 * std::pow(2.0 - t, kRate);
}

double elasticIn(double t) {
    if (t <= 0.0) return 0.0;
    if (t >= 1.0) return 1.0;
    const double p = 0.3;
    const double s = p / 4.0;
    t -= 1.0;
    return -std::pow(2.0, 10.0 * t) * std::sin((t - s) * 2.0 * kPi / p);
}

double elasticOut(double t) {
    if (t <= 0.0) return 0.0;
    if (t >= 1.0) return 1.0;
    const double p = 0.3;
    const double s = p / 4.0;
    return std::pow(2.0, -10.0 * t) * std::sin((t - s) * 2.0 * kPi / p) + 1.0;
}

double elasticInOut(double t) {
    if (t <= 0.0) return 0.0;
    if (t >= 1.0) return 1.0;
    const double p = 0.3 * 1.5;
    const double s = p / 4.0;
    t = t * 2.0 - 1.0;
    if (t < 0.0) {
        return -0.5 * std::pow(2.0, 10.0 * t) * std::sin((t - s) * 2.0 * kPi / p);
    }
    return std::pow(2.0, -10.0 * t) * std::sin((t - s) * 2.0 * kPi / p) * 0.5 + 1.0;
}

double bounceTime(double t) {
    if (t < 1.0 / 2.75) {
        return 7.5625 * t * t;
    }
    if (t < 2.0 / 2.75) {
        t -= 1.5 / 2.75;
        return 7.5625 * t * t + 0.75;
    }
    if (t < 2.5 / 2.75) {
        t -= 2.25 / 2.75;
        return 7.5625 * t * t + 0.9375;
    }
    t -= 2.625 / 2.75;
    return 7.5625 * t * t + 0.984375;
}

double bounceOut(double t) { return bounceTime(t); }

double bounceIn(double t) { return 1.0 - bounceTime(1.0 - t); }

double bounceInOut(double t) {
    if (t < 0.5) return (1.0 - bounceTime(1.0 - t * 2.0)) * 0.5;
    return bounceTime(t * 2.0 - 1.0) * 0.5 + 0.5;
}

double expIn(double t) {
    if (t <= 0.0) return 0.0;
    return std::pow(2.0, 10.0 * (t - 1.0));
}

double expOut(double t) {
    if (t >= 1.0) return 1.0;
    return 1.0 - std::pow(2.0, -10.0 * t);
}

double expInOut(double t) {
    if (t <= 0.0) return 0.0;
    if (t >= 1.0) return 1.0;
    if (t < 0.5) return 0.5 * std::pow(2.0, 10.0 * (t * 2.0 - 1.0));
    return 0.5 * (2.0 - std::pow(2.0, -10.0 * (t * 2.0 - 1.0)));
}

double sineIn(double t) { return 1.0 - std::cos(t * kPi / 2.0); }

double sineOut(double t) { return std::sin(t * kPi / 2.0); }

double sineInOut(double t) { return -0.5 * (std::cos(kPi * t) - 1.0); }

double backIn(double t) {
    return t * t * ((kBackS + 1.0) * t - kBackS);
}

double backOut(double t) {
    t -= 1.0;
    return t * t * ((kBackS + 1.0) * t + kBackS) + 1.0;
}

double backInOut(double t) {
    const double s = kBackS * 1.525;
    t *= 2.0;
    if (t < 1.0) return 0.5 * (t * t * ((s + 1.0) * t - s));
    t -= 2.0;
    return 0.5 * (t * t * ((s + 1.0) * t + s) + 2.0);
}

}  // namespace

double applyEasing(EasingType type, double t) {
    t = clamp01(t);
    switch (type) {
        case EasingType::Linear: return t;
        case EasingType::EaseInOut: return powInOut(t);
        case EasingType::EaseIn: return powIn(t);
        case EasingType::EaseOut: return powOut(t);
        case EasingType::ElasticInOut: return elasticInOut(t);
        case EasingType::ElasticIn: return elasticIn(t);
        case EasingType::ElasticOut: return elasticOut(t);
        case EasingType::BounceInOut: return bounceInOut(t);
        case EasingType::BounceIn: return bounceIn(t);
        case EasingType::BounceOut: return bounceOut(t);
        case EasingType::ExponentialInOut: return expInOut(t);
        case EasingType::ExponentialIn: return expIn(t);
        case EasingType::ExponentialOut: return expOut(t);
        case EasingType::SineInOut: return sineInOut(t);
        case EasingType::SineIn: return sineIn(t);
        case EasingType::SineOut: return sineOut(t);
        case EasingType::BackInOut: return backInOut(t);
        case EasingType::BackIn: return backIn(t);
        case EasingType::BackOut: return backOut(t);
    }
    return t;
}

bool easingFromId(int id, EasingType& out) {
    if (id < 0 || id >= kEasingCount) return false;
    out = static_cast<EasingType>(id);
    return true;
}

int easingToId(EasingType type) {
    return static_cast<int>(type);
}

const char* easingName(EasingType type) {
    const int id = static_cast<int>(type);
    if (id < 0 || id >= kEasingCount) return kNames[0];
    return kNames[id];
}

bool easingFromName(const std::string& name, EasingType& out) {
    for (int i = 0; i < kEasingCount; ++i) {
        if (name == kNames[i]) {
            out = static_cast<EasingType>(i);
            return true;
        }
    }
    return false;
}

}  // namespace gdm
