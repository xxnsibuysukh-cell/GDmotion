#pragma once

#include <string>

namespace gdm {

// Runs a tiny end-to-end check of the core code (easing, evaluate, bake,
// save/load). Returns an empty string when everything is fine, otherwise a
// short description of the first problem.
std::string runSelfCheck();

}  // namespace gdm
