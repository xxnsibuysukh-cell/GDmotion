#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

namespace gdm {

// objectGroups[i] holds the group ids of object i (ids <= 0 mean "no group").
// selected holds indexes of selected objects (out-of-range indexes are ignored).
//
// Returns the indexes, ascending and without duplicates, of the selected
// objects plus every object that shares at least one group with a selected
// object. One step only: objects reached through a newly added group do not
// pull in more groups.
std::vector<size_t> expandSelectionByGroups(const std::vector<std::vector<int32_t> >& objectGroups,
                                            const std::vector<size_t>& selected);

}  // namespace gdm
