#pragma once

#include <string>

namespace gdm {

// Numbers match the Geometry Dash easing ids (0..18) used by triggers.
// The id mapping comes from community documentation; it is not checked
// against the game in this project.
enum class EasingType : int {
    Linear = 0,
    EaseInOut = 1,
    EaseIn = 2,
    EaseOut = 3,
    ElasticInOut = 4,
    ElasticIn = 5,
    ElasticOut = 6,
    BounceInOut = 7,
    BounceIn = 8,
    BounceOut = 9,
    ExponentialInOut = 10,
    ExponentialIn = 11,
    ExponentialOut = 12,
    SineInOut = 13,
    SineIn = 14,
    SineOut = 15,
    BackInOut = 16,
    BackIn = 17,
    BackOut = 18
};

const int kEasingCount = 19;

// t is clamped to [0, 1] (NaN becomes 0). f(0) == 0 and f(1) == 1 for every type.
double applyEasing(EasingType type, double t);

bool easingFromId(int id, EasingType& out);
int easingToId(EasingType type);
const char* easingName(EasingType type);
bool easingFromName(const std::string& name, EasingType& out);

}  // namespace gdm
