#include "Serialize.hpp"

#include <cstddef>
#include <iomanip>
#include <limits>
#include <locale>
#include <sstream>

namespace gdm {
namespace {

const size_t kMaxProjectBytes = 16u * 1024u * 1024u;

std::string cleanName(const std::string& name) {
    std::string out;
    out.reserve(name.size());
    for (size_t i = 0; i < name.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(name[i]);
        out.push_back(c < 0x20 ? ' ' : name[i]);
    }
    return out;
}

std::string trim(const std::string& s) {
    size_t begin = 0;
    size_t end = s.size();
    while (begin < end && (s[begin] == ' ' || s[begin] == '\t')) ++begin;
    while (end > begin && (s[end - 1] == ' ' || s[end - 1] == '\t' || s[end - 1] == '\r')) --end;
    return s.substr(begin, end - begin);
}

ParseResult fail(int lineNo, const std::string& message) {
    ParseResult r;
    r.ok = false;
    r.error = "line " + std::to_string(lineNo) + ": " + message;
    return r;
}

// Reads one whole integer that fits in int32_t.
bool readInt32(std::istringstream& in, int32_t& out) {
    long long v = 0;
    if (!(in >> v)) return false;
    if (v < static_cast<long long>((std::numeric_limits<int32_t>::min)())) return false;
    if (v > static_cast<long long>((std::numeric_limits<int32_t>::max)())) return false;
    out = static_cast<int32_t>(v);
    return true;
}

bool hasExtraText(std::istringstream& in) {
    std::string extra;
    return static_cast<bool>(in >> extra);
}

}  // namespace

std::string serializeProject(const Project& project) {
    std::ostringstream out;
    out.imbue(std::locale::classic());
    out << std::setprecision(17);

    out << "GDMOTION 1\n";
    out << "name " << cleanName(project.name) << "\n";
    out << "fps " << project.fps << "\n";
    out << "length " << project.lengthFrames << "\n";
    for (size_t i = 0; i < project.tracks.size(); ++i) {
        const Track& track = project.tracks[i];
        out << "track " << track.id << " " << track.group << " " << propertyName(track.prop) << "\n";
        for (size_t k = 0; k < track.keys.size(); ++k) {
            const Keyframe& key = track.keys[k];
            out << "key " << key.frame << " " << key.value << " " << easingName(key.easing) << "\n";
        }
        out << "end\n";
    }
    return out.str();
}

ParseResult parseProject(const std::string& text) {
    if (text.size() > kMaxProjectBytes) return fail(0, "file is too large");

    ParseResult result;
    std::istringstream input(text);
    input.imbue(std::locale::classic());

    std::string rawLine;
    int lineNo = 0;
    bool sawHeader = false;
    int currentTrack = -1;  // index into result.project.tracks, -1 = not inside a track

    while (std::getline(input, rawLine)) {
        ++lineNo;
        const std::string line = trim(rawLine);
        if (line.empty() || line[0] == '#') continue;

        std::istringstream words(line);
        words.imbue(std::locale::classic());
        std::string directive;
        words >> directive;

        if (!sawHeader) {
            int32_t version = 0;
            if (directive != "GDMOTION" || !readInt32(words, version)) {
                return fail(lineNo, "this is not a GDmotion project file");
            }
            if (version != 1) return fail(lineNo, "unsupported project version " + std::to_string(version));
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after the version");
            sawHeader = true;
            continue;
        }

        if (directive == "name") {
            result.project.name = trim(line.substr(directive.size()));
        } else if (directive == "fps") {
            if (!readInt32(words, result.project.fps)) return fail(lineNo, "fps must be a whole number");
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after fps");
        } else if (directive == "length") {
            if (!readInt32(words, result.project.lengthFrames)) return fail(lineNo, "length must be a whole number");
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after length");
        } else if (directive == "track") {
            if (currentTrack >= 0) return fail(lineNo, "previous track is missing its 'end' line");
            if (result.project.tracks.size() >= static_cast<size_t>(kMaxTracks)) {
                return fail(lineNo, "too many tracks");
            }
            Track track;
            std::string propText;
            if (!readInt32(words, track.id) || !readInt32(words, track.group) || !(words >> propText)) {
                return fail(lineNo, "track needs: id group property");
            }
            if (!propertyFromName(propText, track.prop)) return fail(lineNo, "unknown property '" + propText + "'");
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after track");
            result.project.tracks.push_back(track);
            currentTrack = static_cast<int>(result.project.tracks.size()) - 1;
        } else if (directive == "key") {
            if (currentTrack < 0) return fail(lineNo, "key found outside a track");
            Track& track = result.project.tracks[static_cast<size_t>(currentTrack)];
            if (track.keys.size() >= static_cast<size_t>(kMaxKeysPerTrack)) {
                return fail(lineNo, "too many keys in one track");
            }
            Keyframe key;
            std::string easingText;
            if (!readInt32(words, key.frame) || !(words >> key.value) || !(words >> easingText)) {
                return fail(lineNo, "key needs: frame value easing");
            }
            if (!easingFromName(easingText, key.easing)) return fail(lineNo, "unknown easing '" + easingText + "'");
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after key");
            track.keys.push_back(key);
        } else if (directive == "end") {
            if (currentTrack < 0) return fail(lineNo, "'end' without a track");
            if (hasExtraText(words)) return fail(lineNo, "unexpected text after end");
            currentTrack = -1;
        } else {
            return fail(lineNo, "unknown line '" + directive + "'");
        }
    }

    if (!sawHeader) return fail(lineNo, "file is empty");
    if (currentTrack >= 0) return fail(lineNo, "last track is missing its 'end' line");

    const std::string problem = validateProject(result.project);
    if (!problem.empty()) {
        result.ok = false;
        result.error = problem;
        return result;
    }
    result.ok = true;
    return result;
}

}  // namespace gdm
