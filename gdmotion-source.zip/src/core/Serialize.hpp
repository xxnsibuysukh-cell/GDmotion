#pragma once

#include <string>

#include "Project.hpp"

namespace gdm {

struct ParseResult {
    bool ok = false;
    std::string error;
    Project project;
};

// Plain-text project format, version 1:
//   GDMOTION 1
//   name My animation
//   fps 30
//   length 300
//   track <id> <group> <posx|posy|rotation|scalex|scaley|alpha>
//   key <frame> <value> <easing-name>
//   end
// Lines starting with # and empty lines are ignored.
std::string serializeProject(const Project& project);

// Never throws. On any problem ok is false and error says why (with line number).
// A successful parse has also passed validateProject().
ParseResult parseProject(const std::string& text);

}  // namespace gdm
